# AI-Smart Expense Tracker and Budget Planner — Backend

## Requirements
- JDK 17 or later
- Maven (or use the Maven Wrapper if you generate one)

## Run in VS Code terminal
From this folder, run:
```powershell
mvn spring-boot:run
```
If `mvn` is not installed, install Maven or open this folder in an IDE configured with Maven.

The server starts at `http://localhost:8080`.

## API endpoints
- `GET /api/transactions` — list all transactions
- `GET /api/transactions/{id}` — get one transaction
- `POST /api/transactions` — create a transaction
- `DELETE /api/transactions/{id}` — delete a transaction

Example POST JSON:
```json
{
  "description": "Lunch",
  "amount": 250,
  "type": "EXPENSE",
  "category": "Food",
  "date": "2026-10-13"
}
```

## Database
Uses an H2 file database stored under `./data` for local learning/demo use.

## Note
The frontend starter is currently a separate demo using browser localStorage; connecting it to these API endpoints is a next step. For production, configure restricted CORS, authentication, validation, and a production database before storing real user data.
